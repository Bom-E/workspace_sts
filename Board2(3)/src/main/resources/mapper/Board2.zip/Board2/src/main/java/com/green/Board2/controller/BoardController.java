package com.green.Board2.controller;

import com.green.Board2.service.BoardService;
import com.green.Board2.vo.BoardVO;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequestMapping("/board")
public class BoardController {
    @Resource(name = "BoardService")
    private BoardService boardService;

    //메인 페이지
    @GetMapping("/list")
    public String boardList(Model model){
        List<BoardVO> selectAll = boardService.selectAll();
        model.addAttribute("selectAll", selectAll);
        return "list";
    }
    //게시글 작성 페이지
    @GetMapping("/writePost")
    public String writePost(){
        return "go_To_Write";
    }
    //게시글 작성
    @PostMapping("/write")
    public String writeThePost(BoardVO boardVO){
        boardService.writePost(boardVO);
        return "redirect:board/detail";
    }
    //게시글 상세 페이지
    @GetMapping("/detail")
    public String selectOne(@RequestParam(name = "boardNum")int boardNum, Model model){
        BoardVO detail = boardService.selectOne(boardNum);
        model.addAttribute("detail", detail);
        return "detail_post";
    }
    //게시글 수정 페이지
    @GetMapping("/goToUpdate")
    public String goToUpdate(BoardVO boardVO, Model model){
        BoardVO update = boardService.selectOne(boardVO.getBoardNum());
        model.addAttribute("update", update);
        return "update_post";
    }
    //게시글 수정
    @PostMapping("/updatePost")
    public String updatePost(BoardVO boardVO){
        boardService.updatePost(boardVO);
        return "redirect:/board/detail?boardNum=" + boardVO.getBoardNum();
    }
    //게시글 삭제
    @GetMapping("/deletePost")
    public String deletePost(BoardVO boardVO){
        boardService.deletePost(boardVO);
        return "redirect:/board/list";
    }
}
