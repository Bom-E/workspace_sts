package com.green.Board2.service;

import com.green.Board2.vo.BoardVO;

import java.util.List;

public interface BoardService {
    List<BoardVO> selectAll();

    int writePost(BoardVO boardVO);

    BoardVO selectOne(int boardNum);

    void updatePost(BoardVO boardVO);

    int deletePost(BoardVO boardVO);
}
