package com.green.Board2.controller;

import com.green.Board2.service.MemberServiceImpl;
import com.green.Board2.vo.MemberVO;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/member")
public class MemberController {
    @Resource(name = "memberService")
    private MemberServiceImpl memberService;

    //로그인 페이지로 이동
    @GetMapping("/loginForm")
    public String loginForm(){
        return "login";
    }
    //회원가입 페이지로 이동
    @GetMapping("/goToJoin")
        public String goToJoin(){
            return "join_to";
    }
    //회원가입
    @PostMapping("/join")
    public String join(MemberVO memberVO){
        memberService.joinWith(memberVO);
        return "redirect:member/loginForm";
    }
}
