package com.green.Board2.service;

import com.green.Board2.vo.BoardVO;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("BoardService")
public class BoardServiceImpl implements BoardService{
    @Autowired
    private SqlSessionTemplate sqlSession;

    @Override
    public List<BoardVO> selectAll() {
        return sqlSession.selectList("boardMapper.selectAll");
    }

    @Override
    public int writePost(BoardVO boardVO) {
        return sqlSession.insert("boardMapper.writePost", boardVO);
    }

    @Override
    public BoardVO selectOne(int boardNum) {
        return sqlSession.selectOne("boardMapper.selectOne", boardNum);
    }

    @Override
    public void updatePost(BoardVO boardVO) {
        sqlSession.update("boardMapper.updatePost", boardVO);
    }

    @Override
    public int deletePost(BoardVO boardVO) {
        return sqlSession.delete("boardMapper.deletePost", boardVO);
    }
}
